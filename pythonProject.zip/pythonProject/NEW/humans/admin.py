from django.contrib import admin
from django.utils.safestring import mark_safe

from .models import Human, Prof


class HumansAdmin(admin.ModelAdmin):
    list_display = ('id', 'profession', 'fio', 'character', 'created_at', 'updated_at', 'get_photo', 'is_published')
    list_display_links = ('id', 'fio')
    search_fields = ('fio', 'character')
    list_filter = ('id', 'is_published')
    list_editable = ['profession', 'is_published']
    fields = ('profession', 'fio', 'character', 'photo', 'created_at', 'updated_at', 'get_photo', 'is_published')
    readonly_fields = ('get_photo', 'created_at', 'updated_at')

    def get_photo(self, obj):
        if obj.photo:
            return mark_safe(f'<img src="{obj.photo.url}" width="75">')
        else:
            return 'Нет фото'

    get_photo_description = 'Миниатюра'


class ProfAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
    list_display_links = ('id', 'title')


admin.site.register(Human, HumansAdmin)
admin.site.register(Prof, ProfAdmin)

admin.site.site_title = 'Страница админа'
admin.site.site_header = 'Страница админа'
