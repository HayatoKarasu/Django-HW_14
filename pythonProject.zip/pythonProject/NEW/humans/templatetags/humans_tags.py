from django.db.models import Count

from humans.models import Prof
from django import template

register = template.Library()


@register.simple_tag(name='get_list_prof')
def get_prof():
    return Prof.objects.all()

@register.inclusion_tag('humans/list_prof.html')
def show_prof(arg1='Prof', arg2='list'):
    #prof = Prof.objects.all()
    prof = Prof.objects.annotate(cnt=Count('human')).filter(cnt__gt=0)
    return {'prof': prof, 'arg1': arg1, 'arg2': arg2}
